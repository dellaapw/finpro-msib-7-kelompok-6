const toggleButton = document.getElementById('toggle-btn');
const sidebar = document.getElementById('sidebar');

// Toggle sidebar.
function toggleSidebar() {
    sidebar.classList.toggle('close');
    toggleButton.classList.toggle('rotate');

    closeAllSubMenu();
}

// Dropdown submenu.
function toggleSubMenu(button) {
    // Check if the current submenu is open.
    if (!button.nextElementSibling.classList.contains('show')) {
        closeAllSubMenu();
    }

    button.nextElementSibling.classList.toggle('show'); // Show the submenu
    button.classList.toggle('rotate'); // Rotate the button

    if (sidebar.classList.contains('close')) {
        sidebar.classList.toggle('close'); // Close the sidebar
        toggleButton.classList.toggle('rotate');
    }
}

// Close all submenu.
function closeAllSubMenu() {
    Array.from(sidebar.getElementsByClassName('show')).forEach(ul => {
        ul.classList.remove('show');
        ul.previousElementSibling.classList.remove('rotate');
    });
}

/* Navigation for SPA */
// Get all navigations and content sections.
const navLinks = document.querySelectorAll('nav ul li a');
const sections = document.querySelectorAll('.content-section');

// Function to remove all 'active' classes.
function removeActiveClasses() {
    navLinks.forEach(link => link.parentElement.classList.remove('active'));
    sections.forEach(section => section.classList.remove('active'));
}

// Function to activate section.
function activateSection(sectionId) {
    const activeLink = document.querySelector(`[data-section="${sectionId}"]`);
    const activeSection = document.getElementById(sectionId);

    // Add 'active' class to the link and section.
    activeLink.parentElement.classList.add('active');
    activeSection.classList.add('active');
}

// Event listener for each navigation link.
navLinks.forEach(link => {
    link.addEventListener('click', (event) => {
        event.preventDefault();

        const sectionId = link.getAttribute('data-section');

        // Remove all 'active' classes and activate the section.
        removeActiveClasses();
        activateSection(sectionId);
    });
});

